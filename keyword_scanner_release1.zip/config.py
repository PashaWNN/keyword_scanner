APP_NAME        = 'KeywordScanner' # Название приложения
SECRET_KEY_FILE = '.secret_key'    # Путь до файла с секретным ключом
PASSWORD_HASH_F = '.password'      # Путь до файла с хэшем пароля
MAX_TASKS       = 5                # Максимальное количество заданий в списке
